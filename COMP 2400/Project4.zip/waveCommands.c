#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "wave.h"

#define SAMPLE_RATE 44100
enum {
	CMD_LINE_ERR,
	MEMORY_ERR,
	RIFF_ERR,
	CHUNK_FMT_ERR,
	CHUNK_DATA_ERR,
	NOT_STEREO_ERR,
	INVALID_SPL_RATE,
	INVALID_SPL_SIZE,
	INVALID_FILE_SIZE,
	INVALID_SPD,
	INVALID_TIME,
	INVALID_VOL,
	INVALID_ECHO
}; 


void generateError(int errCode);
void reverse(short* channel, int length);
short* changeSpeed(short* channel, double factor, int length);
void fadeOut(short* channel, double numSeconds, int length);
void fadeIn(short* channel, double numSeconds, int length);
void volume(short* channel, double scale, int length);
short* echo(short* channel, double delay, double scalingFactor, int length);
short clamp(double value);

int main(int argc, char **argv)
{
  WaveHeader header;
  int r = readHeader(&header);
  if(strncmp(header.ID, "RIFF", 4) != 0)
  {
  	generateError(RIFF_ERR);
  }
  else if(strncmp(header.formatChunk.ID, "fmt ", 4) != 0 || header.formatChunk.size != 16 || header.formatChunk.compression != 1)
  {
  	generateError(CHUNK_FMT_ERR);
  }
  else if(strncmp(header.dataChunk.ID, "data", 4) != 0)
  {
  	generateError(CHUNK_DATA_ERR);
  }
  else if(header.formatChunk.channels != 2)
  {
  	generateError(NOT_STEREO_ERR);
  }
  else if(header.formatChunk.sampleRate != SAMPLE_RATE)
  {
  	generateError(INVALID_SPL_RATE);
  }
  else if(header.formatChunk.bitsPerSample != 16)
  {
  	generateError(INVALID_SPL_SIZE);
  }
  int length = header.dataChunk.size/4;
  short* leftChannel = (short*)malloc(sizeof(short)*length);
  short* rightChannel = (short*)malloc(sizeof(short)*length);
  if(leftChannel == NULL || rightChannel == NULL)
  {
  	generateError(MEMORY_ERR);
  }

  for(int j = 0; j < length; j++)
  {
    int firstByte = getchar();
    if(firstByte == EOF)
    {
    	generateError(INVALID_FILE_SIZE);
    }
    int secondByte = getchar() << 8;
    if(secondByte == EOF)
    {
    	generateError(INVALID_FILE_SIZE);
    }
    leftChannel[j] = firstByte + secondByte;
    firstByte = getchar();
    if(firstByte == EOF)
    {
    	generateError(INVALID_FILE_SIZE);
    }
    secondByte = getchar() << 8;
    if(secondByte == EOF)
    {
    	generateError(INVALID_FILE_SIZE);
    }
    rightChannel[j] = firstByte + secondByte;
  }

  int i = 1;

    while(i < argc) // arguments possible:  r, s, f, o, i, v, e
    {

      if (strcmp(argv[i], "-r") == 0) //Reverse the audio
      {
        reverse(leftChannel, length);
        reverse(rightChannel, length);
      }
      else if (strcmp(argv[i], "-s") == 0) //Change audio speed by a specific factor
      {
        ++i;
        double inputFactor = atof(argv[i]);
        if(inputFactor <= 0.0)
        {
          generateError(INVALID_FILE_SIZE);
        }
        leftChannel = changeSpeed(leftChannel, inputFactor, length);
        rightChannel = changeSpeed(rightChannel, inputFactor, length);

        length = length/inputFactor;
        
      }
      else if (strcmp(argv[i], "-f") == 0) //Flip the left and the right stereo channels
      {
        short* temp = leftChannel;
        leftChannel = rightChannel;
        rightChannel = temp;
      }
      else if (strcmp(argv[i], "-o") == 0) //Fade out from full volume to zero at the end of the file over a specified time
      {
        ++i;
        double seconds = atof(argv[i]);
        if (seconds <= 0)
        {
          generateError(INVALID_TIME);
        }
        fadeOut(leftChannel, seconds, length);
        fadeOut(rightChannel, seconds, length);
      }
      else if (strcmp(argv[i], "-i") == 0) //Fade in from zero to full volume at the beginning of the file over a specified time
      {
        ++i;
        double seconds = atof(argv[i]);
        if (seconds <= 0)
        {
          generateError(INVALID_TIME);
        }
        fadeIn(leftChannel, seconds, length);
        fadeIn(rightChannel, seconds, length);
      }
      else if (strcmp(argv[i], "-v") == 0) //Scale the volume of the file by a specified amount
      {
        ++i;
        double scaleInput = atof(argv[i]);
        if (scaleInput <= 0.0)
        {
          generateError(INVALID_VOL);
        }
        volume(leftChannel, scaleInput, length);
        volume(rightChannel, scaleInput, length);
      }
      else if (strcmp(argv[i], "-e") == 0) //Add an echo to the sound with a specified delay and a specific scale factor
      {
      	++i;
      	double delay = atof(argv[i]);
      	if (delay <= 0.0)
        {
          generateError(INVALID_ECHO);
        }
      	++i;
      	double scalingFactor = atof(argv[i]);
      	if (scalingFactor <= 0.0)
        {
          generateError(INVALID_ECHO);
        }
      	
      	leftChannel = echo(leftChannel, delay, scalingFactor, length);
      	rightChannel = echo(rightChannel, delay, scalingFactor, length);
      	int delaySamples = (delay * SAMPLE_RATE);
		length = length + delaySamples;
      }
      else
      {
		generateError(CMD_LINE_ERR);
      }

      i++;
    }

	header.dataChunk.size = length * 4;
	header.size = header.dataChunk.size + 36;
	writeHeader(&header);
    for(int j = 0; j < length; ++j)
    {
      //dividing the bytes back into ints and putting the indv values in each channel
      putchar(leftChannel[j]);
      putchar(leftChannel[j] >> 8);
      putchar(rightChannel[j]);
      putchar(rightChannel[j] >> 8);

    }



  return 0;
}

void reverse(short* channel, int length)
{
  for(int i = 0; i < length/2; i++)
  {
    short temp = channel[i];
    channel[i] = channel[(length)-1-i];
    channel[(length)-1-i] = temp;
  }

}

short* changeSpeed(short* channel, double factor, int length)
{
  short* newChannel = (short*)malloc(sizeof(short)*(length/factor));
  for(int i = 0; i < (length/factor); ++i)
  {
    newChannel[i] = channel[(int)(i * factor)];
  }
  free(channel);
  return newChannel;
}

void fadeOut(short* channel, double numSeconds, int length)
{
  double n = (int)(SAMPLE_RATE * numSeconds);
  int start = length - n;

  for(int i = length-1; i >= 0 && i >= start; --i)
  {
     channel[i] *= (1.0 - (i - start)/n) * (1.0 - (i - start)/n);
  }
}

void fadeIn(short* channel, double numSeconds, int length)
{
	double n = (int)(SAMPLE_RATE * numSeconds);
	for(int i = 0; i < n && i < length; ++i)
	{
		channel[i] *= (i/n) * (i/n);
	}
}

void volume(short* channel, double scale, int length)
{
	for(int i = 0; i < length; ++i)
	{
    channel[i] = clamp(channel[i]*scale);
	}
}

short clamp(double value)
{
  if(value > SHRT_MAX)
  {
    return SHRT_MAX;
  }
  else if (value < SHRT_MIN)
  {
    return SHRT_MIN;
  }
  else
  {
    return (short)value;
  }
}

short* echo(short* channel, double delay, double scalingFactor, int length)
{

	int delaySamples = (delay * SAMPLE_RATE);
	int n = length + delaySamples;
	short* newChannel = (short*)calloc(n, sizeof(short));
	for(int i = 0; i < length; ++i)
	{
		newChannel[i] = channel[i];
	}
	for(int i = delaySamples; i < n; ++i)
	{
		newChannel[i] = clamp(channel[i-delaySamples] * scalingFactor + newChannel[i]); 
	}
	free(channel);
	return newChannel;

}

void generateError(int errCode)  //Generates an error message based on the input and sends it to stderr. Also exits after generating.
{
	switch(errCode)
	{
		case 0:  //Command line usage
			fprintf(stderr, "Usage: wave [[-r][-s factor][-f][-o delay][-i delay][-v scale][-e delay scale]] < input > output\n");
			break;
		case 1:  //Insufficient memory
			fprintf(stderr, "Program out of memory\n");
			break;
		case 2:  //File not RIFF
			fprintf(stderr, "FIle is not a RIFF file\n");
			break;
		case 3:  //Bad format chunk
			fprintf(stderr, "Format chunk is corrupted\n");
			break;
		case 4:  //Bad data chunk
			fprintf(stderr, "Data chunk is corrupted\n");
			break;
		case 5:  //Not stereo
			fprintf(stderr, "File is not stereo\n");
			break;
		case 6:  //Invalid sample rate
			fprintf(stderr, "File does not use 44,100Hz sample rate\n");
			break;
		case 7:  //Invalid sample size
			fprintf(stderr, "File does not have 16-bit samples\n");
			break;
		case 8:  //Invalid file size
			fprintf(stderr, "File size does not match size in header\n");
			break;
		case 9:  //Invalid speed
			fprintf(stderr, "A positive number must be supplied for the speed change\n");
			break;
		case 10:  //Invalid time
			fprintf(stderr, "A positive number must be supplied for the fade in and fade out time\n");
			break;
		case 11:  //Invalid volume
			fprintf(stderr, "A positive number must be supplied for the volume scale\n");
			break;
		case 12:  //Invalid echo
			fprintf(stderr, "Positive numbers must be supplied for the echo delay and scale parameters\n");
			break;
		default:
			fprintf(stderr, "Unidentified error: %d\n", errCode);
			break;
	}
	exit(0);

}
