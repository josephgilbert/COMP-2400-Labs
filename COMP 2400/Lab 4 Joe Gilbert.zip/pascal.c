#include <stdio.h>

int readInt(void);
long long factorial(int n);


int main()
{
	int n, k, j, t;
	printf("Input a number between 0 and 20: ");
	n = readInt();
	
	if( n > 20 )
	{
		printf("Invalid input\n");
		return 1;
	}
	else
	{
		for( k = 0; k < n; ++k)
		{
			for( j = 0; j <= k; ++j)
			{
				t = factorial(k) / (factorial(k - j) * factorial(j));
				printf("%d ",t);
			}
			printf("\n");
		}
	}
	return 0;
}


int readInt()
{
	int c = 0;
	int i = 0;
  
	while( (c = getchar()) != EOF && c != '\n' )
	{
		if( c >= '0' && c <= '9')	
			i = i * 10 + (c - '0');	
	}
	return i;
}


long long factorial(int n)
{
	if( n <= 1 )
	{
		return 1;
	}
	else
	{
		return n*factorial(n - 1);
	}
}



