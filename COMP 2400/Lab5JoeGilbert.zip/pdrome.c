#include <stdio.h>
#define SIZE 1024

int palindrome(char str[], int size);
unsigned char lowerCase(unsigned char c);

int main()
{
	char inputString[SIZE+1];
	char workString[SIZE+1];
	int strSize = 0;
	int c;
	printf("Enter a string: ");

	while((c = getchar()) != EOF && c != '\n' && strSize < SIZE)
	{
		inputString[strSize] = c;
		workString[strSize] = lowerCase(c);
		strSize += 1; 
	} 
	inputString[strSize] = '\0';
	workString[strSize] = '\0';
	int result = palindrome(workString, strSize);
	if(result != 0)
	{
		printf("The string \"%s\" is a palindrome.\n", inputString);
	}
	else
	{
		printf("The string \"%s\" is not a palindrome.\n", inputString);
	}
	return 0;
}

//Function to determine whether a string is a palindrome or not.
//Returns 1 if it is, 0 if not.
int palindrome(char str[SIZE], int size)
{
	int result = 1;
	for(int i = 1; i < size; ++i)
	{
		if(str[i] != str[size - i - 1])
		{
			result = 0;
			return result;
		}
		else
		{
			result = 1;
		}
	}
	return result;
}

//Converts a letter to lowercase.
unsigned char lowerCase(unsigned char c)
{
	int mask = 1 << 5;
	if (c >= 'A' && c <= 'Z')
	{
		c = (c | mask);
	}
	return c;

}
