#include "new_string.h"
#include <stddef.h>


/*
 Copies the characters from source into destination.
 */
char* new_strcpy(char* destination, const char* source){
    
	int i;
    for(i = 0; source[i]; ++i){
        
        destination[i] = source[i];
        
    }
    destination[i] = '\0';
    return destination;
}


/*
 Copies the first n characters from source into destination. If the function hits a null character in source before it has copied n characters, the remaining characters are filled with null characters
 */
char* new_strncpy(char* destination, const char* source, size_t n){
    
    int i;
    for(i = 0; i < n && source[i]; ++i){
        
		destination[i] = source[i];
        
    }
    destination[i] = '\0';
    return destination;
    
}

/*
 Compares two strings. The return value is positive if string1 comes after string2 alphabetically, negative if string1 comes before string2 alphabetically, and 0 if the two strings are equal.
 */
int new_strcmp(const char* string1, const char* string2){
	int len1 = 0;
	for(int i = 0; string1[i]; ++i){
		++len1;
	}
	int len2 = 0;
	for(int i = 0; string2[i]; ++i){
		++len2;
	}
	
	if(len1 < len2){
		for(int i = 0; i < len1; ++i){
			if(string1[i] < string2[i]){
				return -1;
			}
			else if (string1[i] > string2[i]){
				return 1;
			}
		}
		return -1;
	}
	else if(len2 < len1){
		for(int i = 0; i < len2; ++i){
			if(string1[i] < string2[i]){
				return -1;
			}
			else if (string1[i] > string2[i]){
				return 1;
			}
		}
		return 1;
	}
	else {
		for(int i = 0; i < len2; ++i){
			if(string1[i] < string2[i]){
				return -1;
			}
			else if (string1[i] > string2[i]){
				return 1;
			}
		}
		return 0;
	
	}
}

/*
 Compares two strings exactly like new_strcmp(), except comparing at most the first n characters.
 */
int new_strncmp(const char* string1, const char* string2, size_t n){
	int len1 = 0;
	for(int i = 0; string1[i]; ++i){
		++len1;
	}
	if(len1 > n){
		len1 = n;
	}
	int len2 = 0;
	for(int i = 0; string2[i]; ++i){
		++len2;
	}
	if(len2 > n){
		len2 = n;
	}
	
	if(len1 < len2){
		for(int i = 0; i < len1; ++i){
			if(string1[i] < string2[i]){
				return -1;
			}
			else if (string1[i] > string2[i]){
				return 1;
			}
		}
		return -1;
	}
	else if(len2 < len1){
		for(int i = 0; i < len2; ++i){
			if(string1[i] < string2[i]){
				return -1;
			}
			else if (string1[i] > string2[i]){
				return 1;
			}
		}
		return 1;
	}
	else {
		for(int i = 0; i < len2; ++i){
			if(string1[i] < string2[i]){
				return -1;
			}
			else if (string1[i] > string2[i]){
				return 1;
			}
		}
		return 0;
	
	}
}

/*
 Adds the string contained in source to the end of the string contained in destination. The values in destination are modified, but a pointer to destination is also returned.
 */
char* new_strcat(char* destination, const char* source){

    int lenDest = 0;
    
    for(int i = 0; destination[i]; ++i){
        
        ++lenDest;
        
    }
    int j;

    for(j = 0; source[j]; ++j){
        destination[j + lenDest] = source[j];
    
    }
    destination[j + lenDest] = '\0';
    return destination;

    
}

/*
 Adds the string contained in source to the end of the string contained in destination, but adding a maximum of n characters.
 */
char* new_strncat(char* destination, const char* source, size_t n){
    
    int lenDest = 0;
    
    for(int i = 0; destination[i]; ++i){
        
        ++lenDest;
        
    }
    
    int lenSource = 0;
    
    for(int i = 0; source[i]; ++i){
        
        ++lenSource;
        
    }
    
    if(lenSource < n){
        
        n = lenSource;
    }
    
    int j;

    for(j = 0; source[j]; ++j){
        
        if(j < n){
            destination[j + lenDest] = source[j];
        }
    
    }
    destination[j + lenDest] = '\0';
    return destination;
    
}

/*
 Returns the number of characters in string before the null character.
 */
size_t new_strlen(const char* string){
    
    int sum = 0;
    
    for(int i = 0; string[i]; ++i){
        
        ++sum;
        
    }
    return sum;
    
}

/*
 Returns a pointer to the first occurrence of character in string or a NULL pointer if character cannot be found.
 */
char* new_strchr(const char* string, int character){
	char* pointer = NULL;
	
	for(int i = 0; string[i]; ++i)
	{
		if(string[i] == character)
		{
			pointer = (char*)&string[i];
			return pointer;
		}
	}
    
	return pointer;
}

/*
 Returns a pointer to the first occurrence of the string contained in needle in haystack or a NULL pointer if needle cannot be found.
 */

char* new_strstr(const char* haystack, const char* needle){
    
    for(int i = 0; haystack[i]; ++i){
        int j = 0;
        
        while(needle[j] && haystack[i + j] == needle[j]){
            
            ++j;
                
            }
        if (needle[j] == '\0'){
            
            return (char*)&haystack[i];
            
        }
        
    }
    
    return NULL;

}

