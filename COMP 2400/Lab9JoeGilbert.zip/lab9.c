#include <stdio.h>
#include <stdlib.h>

typedef struct _LinkNode 
{
	int data;
	struct _LinkNode* next;
} LinkNode;


LinkNode* add(LinkNode* head, int value);
LinkNode* delete(LinkNode* head, int value);
void print(LinkNode* head);
void empty(LinkNode* head);
int readInt();



int main()
{
	LinkNode* head = NULL;
	int n, value, boln;
	boln = 1;
	while(boln == 1){
		printf("1. Add new element\n");
		printf("2. Delete element\n");
		printf("3. Print list\n");
		printf("4. Exit\n");
		n = readInt();
		if(n == 1)
		{
			value = readInt();
			head = add(head, value);
		}
		else if(n == 2)
		{
			value = readInt();
			head = delete(head, value);
		}
		else if(n == 3)
		{
			print(head);
		}
		else
		{
			boln = 0;
		}
	}
	empty(head);
	return 0;
}

int readInt()
{
	int c = 0;
	int i = 0;
  
	while( (c = getchar()) != EOF && c != '\n' )
	{
		if( c >= '0' && c <= '9')	
			i = i * 10 + (c - '0');	
	}
	return i;
}

LinkNode* add(LinkNode* head, int value)
{
	LinkNode* newNode = (LinkNode*)malloc(sizeof(LinkNode));
	newNode->data = value;
	newNode->next = head;
	return newNode;
}

LinkNode* delete(LinkNode* head, int value)
{
	LinkNode* temp = head;
	if(head == NULL)
	{
		return head;
	}
	else if(head->data == value)
	{
		LinkNode* newHead = head->next;
		free(head);
		return newHead;
	}
	else
	{
		while(temp->next != NULL)
		{
			if(temp->next->data == value)
			{
				LinkNode* nextNode = temp->next;
				LinkNode* nextNextNode = nextNode->next;
				temp->next = nextNextNode;
				free(nextNode);
				return head;
			}
		}
	}
	return head;
	
}

void print(LinkNode* head)
{
	LinkNode* current = head;
	while(current != NULL)
	{
		printf("%d ", current->data);
		LinkNode* next = current->next;
		current = next;
	}
	printf("\n");
}

void empty(LinkNode* head)
{
	LinkNode* current = head;
	while(current != NULL)
	{
		LinkNode* next = current->next;
		free(current);
		current = next;
	}
}

