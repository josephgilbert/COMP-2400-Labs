#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define MESSAGE_SIZE 1024

void readLine(char line[]);


int main()
{
	char ipAddress[15];
	unsigned int portNumber;
	char username[21];
	int socketFD = -1;
	socketFD = socket(AF_INET, SOCK_STREAM, 0);
	
	printf("Enter IP: ");
	scanf("%s", ipAddress);
	
	printf("Enter port: ");
	scanf("%u", &portNumber);
	
	printf("Enter user name: ");
	scanf("%s", username);
	getchar();
	struct sockaddr_in address;
	memset(&address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_port = htons(portNumber);
	inet_pton(AF_INET, ipAddress, &(address.sin_addr));
	
	connect(socketFD, (struct sockaddr *) &address, sizeof(address));
	char buffer[1024];
	char* quitMsg = "quit"; 
	char message[1024];
	printf("%s: ", username);
	readLine(buffer);
	while(strcmp(buffer, quitMsg) != 0)
	{
		sprintf(message,"%s: %s", username, buffer);
		send(socketFD, message, strlen(message)+1, 0);
		printf("%s: ", username);
		readLine(buffer); 
	}
	
	send(socketFD, quitMsg, strlen(quitMsg)+1, 0);
	
	
}

void readLine(char line[])
{	
	int c = 0;	
	int i = 0;

	while( (c = getchar()) != '\n' )
	{
		line[i] = c;
		i++;
	}

	line[i] = '\0';
}
