/*******************************/
/*
/*  Project Name: Project 1
/*  Description: Various functions to find the first 50 numbers of sequences.
/*  File names: project.c
/*  Date: 1/31/20   
/*  Authors: Joe Gilbert, Jarrett Gorecki
/*
/*******************************/


#include <stdio.h>

void caterers(); 
void primes();
void fibonacci();
void collatz();
void happy();
int digitsumsquared(int n);

int main() 
{
	printf("Lazy Caterer's Sequence:\n");
	caterers();
	printf("\n");
	printf("\n");
	printf("Prime Numbers:\n");
	primes();
	printf("\n");
	printf("\n");
	printf("Fibonacci Sequence:\n");
	fibonacci();
	printf("\n");
	printf("\n");
	printf("Collatz Stopping Times:\n");
	collatz();
	printf("\n");
	printf("\n");
	printf("Happy Numbers:\n");
	happy();
	printf("\n");
	return 0;
}

//Finds and prints out the first 50 Lazy Caterer's numbers.
void caterers()
{
	int n;

	for (n = 0; n <= 49; ++n)
	{
		printf("%d ", (((n*n) + n + 2) / 2));
	}
}

//Finds and prints out the first 50 prime numbers.
void primes()
{
	int count = 0;
	int i = 2, j;
	while (count < 50)
	{
		for (j = 2; j < i; ++j)
		{
			if ( i % j == 0 ) 
			{
				break;
			}
		}
		if (j == i)
		{
			printf("%d ", j);
			++count;
		}
		++i;
	}
}

//Finds and prints out the first 50 Fibonacci numbers.
void fibonacci()
{
	int c;
	long long n = 1;
	long long i = 0;
	long long j = 0;
	
	for (c = 0; c < 50; ++c)
	{
		printf("%lld ", n);
		i = j;
		j = n;
		n = i + j;
	}
}

//Finds and prints out the first 50 numbers of the Collatz sequence.
void collatz()
{
	int n, i;
	int count;
	for (i = 1; i < 51; ++i)
	{
		count = 0;
		n = i;
		while (n > 1)
		{
			if (n % 2 == 0)
			{
				n = n / 2;
			}
			else
			{
				n = (3 * n) + 1;
			}
			++count;
		}
		printf("%d ", count);
	}
}

//Finds the first 50 happy numbers.  Calls on the digitsumsquared function
//to do the calculations.
void happy()
{
	int i = 0;
	int n = 1;
	int j;
	while (i < 50)
	{
		j = n;
		while (j != 4) 
		{
			if (j == 1) 
			{
				printf("%d ", n);
				++i;
				break;
			}
			else
			{
				j = digitsumsquared(j);
			}
		}
		++n;
	}
}

//Takes the integer n as a parameter.
//Returns the sum of the square of the digits of n.
int digitsumsquared(int n)
{
	int raw = n;
	int new = 0;

	while(raw>0)
	{
		new += (raw%10) * (raw%10);
		raw /= 10;
	}
	return new;
}
