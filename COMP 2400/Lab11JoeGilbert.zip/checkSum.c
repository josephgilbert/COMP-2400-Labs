#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>

#define BLOCK_SIZE 512
#define BIG_NUMBER 65536 //2 to the 16.

unsigned int getCheckSum(unsigned int sum);

int main(int argc, char **argv)
{
	int blockCount = 0;
	unsigned int byteCount;
	unsigned char buffer[BLOCK_SIZE];
	unsigned int sum = 0;
	if(argc != 2)
	{
		printf("Usage: ./checksum <filename>\n");
		exit(1);
	}
	else
	{
		int fd = open(argv[1], O_RDONLY);
		if (fd < 0)
		{
			printf("./checksum: %s: No such file or directory\n", argv[1]);
			exit(1);
		}
		//read returns number of bytes successfully read.
		//So, everytime we run this, it should be 512 or less.
		//The buffer flushes everytime it gets full. 
		do
		{
			byteCount = read(fd, buffer, sizeof(buffer));
			for(int i = 0; i < byteCount; ++i)
			{
				sum += buffer[i];
			}
			++blockCount;
			
		} while(byteCount == BLOCK_SIZE);

		
		close(fd);
		unsigned int checksum = getCheckSum(sum);
		
		printf("%u %d %s\n", checksum, blockCount, argv[1]);
		
	}
	
	
	return 0;
}



unsigned int getCheckSum(unsigned int sum)
{
	unsigned int r = (sum % BIG_NUMBER) + (sum / BIG_NUMBER);
	unsigned int s = (r % BIG_NUMBER) + (r / BIG_NUMBER);
	return s;
}
