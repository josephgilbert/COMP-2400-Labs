#include <stdio.h>
#define LENGTH 2048
#define DELIMITER 255

unsigned char rotate(unsigned char character, int count);
int bits(unsigned char character);

int main()
{
	unsigned char message[LENGTH];
	int messageSize = 0;
	unsigned char key[LENGTH];
	int keySize = 0;
	int c;
	
	//Put the message into the message array one character at a time.
	//While the chracter we see is NOT the delimiter:
	while((c = getchar()) != DELIMITER)
	{
		//If there's still available space in the message array, append c.
		if(messageSize < LENGTH)
		{
			message[messageSize] = c;
			++messageSize;
		}
	}
	
	//Put the key into the key array one character at a time.
	while((c = getchar()) != EOF && keySize < LENGTH)
	{
		key[keySize] = c;
		++keySize;
	}
	
	int difference = messageSize - keySize;
	//Make the key longer by tiling. 
	for(int i = 0; i < difference; ++i)
	{
		key[keySize + i] = key[i];
	}
	
	//Initialize the sum as the last character in the key mod the size of the key and message.
	int sum = key[messageSize-1] % messageSize;
	for(int i = 0; i < messageSize; ++i)
	{
		//For the first entry, rotate the key entry by the number of 1's in the last entry of the key.
		//Else, rotate the key entry by the number of 1's in the previous entry. 
		if(i == 0)
		{
			key[i] = rotate(key[i]^key[sum], bits(key[messageSize-1]));
		}
		else
		{
			key[i] = rotate(key[i]^key[sum], bits(key[i-1]));
		}
		sum = (sum + key[i]) % messageSize;
	}
	
	//XOR each character in the message array with the corresponding character in the key array.
	for(int i = 0; i < messageSize; ++i)
	{
		putchar(message[i] ^ key[i]);
	}
}


//Performs rotation on a character by count places.
unsigned char rotate(unsigned char character, int count)
{
	int i;
	int mask1 = 1;
	int mask6 = 1 << 6;
	//mask6 is just 01000000
	//Before rotating, we ask whether the character has a 1 in the 0's place.
	//If it does, we bit shift right by 1, and set the second to last bit.
	//Else, we shift right by 1 and unset the second to last bit.
	for(i = 0; i < count; ++i)
	{
		if(character & mask1)
		{
			character >>= 1;
			character = character | mask6;
		}
		else
		{
			character >>= 1;
			character = character & ~(mask6);
		}
	}
	return character;
}

//Returns the number of 1 bits in a character.
int bits(unsigned char character)
{
	int mask = 1;
	int numOfOnes = 0;
	int i;
	//Basically look at each bit in the character.
	//If it has a 1 for a bit, increment the numOfOnes counter.
	for(i = 0; i < 7; ++i)
	{
		if(character & mask)
		{
			numOfOnes += 1;
		}
		mask <<= 1;
	}
	return numOfOnes;
}


