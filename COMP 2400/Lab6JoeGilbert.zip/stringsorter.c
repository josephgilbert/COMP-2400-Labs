#include <stdio.h>
#include <string.h>

void backwards(char* argv[], int count);
void reverse(char* argv[], int count);
void sort(char* argv[], int count);

int main(int argc, char* argv[])
{
	int i = 1;
	if(argv[1][0] == '-')
	{
		while(argv[1][i] != '\0')
		{
			if(argv[1][i] == 'b')
			{
				backwards(argv, argc);
			}
			else if(argv[1][i] == 'r')
			{
				reverse(argv, argc);
			}
			else if(argv[1][i] == 's')
			{
				sort(argv, argc);
			}
			++i;
			
		}
	}
	for(int j = 2; j < count; ++j)
	{
		printf("%s ", argv[j]);
	}
}

void backwards(char* argv[], int count)
{
	for(int i = 2; i < count; ++i)
	{
		char* word = argv[i];
		
		length = strlen(word);
		for(int j = 0; j < length/2; j++)
		{

			char* temp = word[j];
			char* a = temp;
			char* b = word[j + 1];
			temp = b;
			
			
		}
	}
}

void reverse(char* argv[], int count)
{
	char* words = argv;
	char* wordscopy = argv;
	int i = 2;
	while(i < count)
	{
		words[i] = wordscopy[count - 1 - i];
	}
}

void sort(char* argv[], int count)
{
	for(int i = 2; i < count - 1; ++i)
	{
		char* current = argv[i];
		char* next = argv[i + 1];
		if(strcmp(current, next))
		{
		
		}
	}
}
