#include <stdio.h>
#include <stdlib.h>

void merge(int array1[], int length1, int array2[], int length2, int result[]);

int main()
{
	int length1;
	scanf("%d", &length1);
	int length2;
	scanf("%d", &length2);
	int* array1 = (int*)malloc(sizeof(int) * length1);
	int* array2 = (int*)malloc(sizeof(int) * length2);
	for(int i = 0; i < length1; ++i)
	{
		scanf("%d", &array1[i]);
	}
	for(int j = 0; j < length2; ++j)
	{
		scanf("%d", &array2[j]);
	}
	int* result = (int*)malloc(sizeof(int) * (length1 + length2));
	merge(array1, length1, array2, length2, result);
	
	printf("List 1: ");
	for(int i = 0; i < length1; ++i)
	{
		printf("%d ", array1[i]);
	}
	printf("\n");
	printf("List 2: ");
	for(int j = 0; j < length2; ++j)
	{
		printf("%d ", array2[j]);
	}
	printf("\n");
	printf("Merged List: ");
	for(int k = 0; k < (length1 + length2); ++k)
	{
		printf("%d ", result[k]);
	}
	printf("\n");
	
	free(array1);
	free(array2);
	free(result);
	
	return 0;
}

void merge(int array1[], int length1, int array2[], int length2, int result[])
{
	int i = 0;
	int j = 0;
	int k = 0;
	while(i < length1 && j < length2)
	{
		if(array1[i] < array2[j])
		{
			result[k] = array1[i];
			++i;
		}
		else
		{
			result[k] = array2[j];
			++j;
		}
		++k;
	}
	while(i < length1)
	{
		result[k] = array1[i];
		++i;
		++k;
		
	}
	while(j < length2)
	{
		result[k] = array2[j];
		++j;
		++k;
		
	}
	

	
}

